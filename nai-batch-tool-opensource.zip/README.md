# NAI 작가 태그 자동 업로드 도구

[NAI 작가 태그 서가](../) 웹앱과 함께 쓰는 파이썬 스크립트 모음입니다. `.docx` 표에서
작가 태그명을 읽어서, NovelAI로 girl/boy/빈프롬 3장씩 이미지를 자동 생성하고, 웹앱과
동일한 Firestore 데이터베이스에 자동으로 저장합니다.

이 저장소는 **본인 컴퓨터에서 직접 실행**하는 스크립트 모음이며, 서버에 올려서 돌리는
용도가 아닙니다.

> ⚠️ 라이선스 안내: 이 프로젝트는 개인적으로 자유롭게 쓰고 수정·재배포할 수 있지만,
> **상업적 이용**이나 **여러 명이 함께 쓰는 서비스 형태로 운영**하려면 원저작자의
> 사전 허락이 필요합니다. 자세한 내용은 [LICENSE.md](./LICENSE.md)를 확인해주세요.

---

## 포함된 스크립트

| 파일 | 하는 일 |
|---|---|
| `upload_tags.py` | `.docx` 표의 태그명을 읽어 NAI로 이미지 3장(girl/boy/빈프롬)을 생성하고, Supabase Storage에 업로드한 뒤 Firestore에 저장 |
| `reset_styles.py` | Firestore `artistTags` 컬렉션의 화풍/분류 태그(`styles`)만 전부 빈 배열로 초기화 (다른 데이터는 그대로 유지) |

---

## 1. 준비물

- Python 3.10 이상
- NovelAI 계정 & API 토큰
- [NAI 작가 태그 서가](../) 웹앱에서 쓰는 것과 **같은** Firebase 프로젝트
- Firebase 서비스 계정 키 (`.json` 파일)
- (이미지 업로드 기능을 쓰려면) 웹앱에서 쓰는 것과 같은 Supabase 프로젝트

---

## 2. 설치
우선 [파이썬 공홈](https://www.python.org/downloads/)에서 파이썬을 다운받습니다.4

터미널에서 아래 내용을 입력하세요.
```bash
python -m pip install -r requirements.txt
```

`pip`가 인식되지 않으면 `python -m pip install -r requirements.txt` 형태로 실행하세요
(Windows에서 흔히 겪는 문제입니다).

---

## 3. Firebase 서비스 계정 키 발급

1. [Firebase 콘솔](https://console.firebase.google.com/) → 웹앱과 연결된 프로젝트 선택
2. 프로젝트 설정(톱니바퀴) → **서비스 계정** 탭
3. **새 비공개 키 생성** → 다운로드된 `.json` 파일을 이 폴더 안에 넣기

⚠️ 이 파일은 Firestore 데이터베이스에 대한 완전한 접근 권한을 가집니다. **절대 공개
저장소에 커밋하거나 다른 사람과 공유하지 마세요.** (`.gitignore`에 이미 제외 패턴이
포함되어 있습니다.)

---

## 4. NovelAI API 토큰 발급

1. [novelai.net](https://novelai.net) 로그인 → Account 설정
2. **Get Persistent API Token** 항목에서 토큰 발급 → 복사해두기

---

## 5. `upload_tags.py` 사용법

### 5-1. 설정값 채우기

파일 상단의 "설정값" 섹션을 열어 채워주세요:

```python
DOCX_PATH = "tags.docx"                    # 태그명이 든 .docx 파일 경로
NAI_API_TOKEN = "..."                      # NovelAI API 토큰
SERVICE_ACCOUNT_PATH = "serviceAccountKey.json"
SUPABASE_URL = "https://xxxxx.supabase.co"
SUPABASE_ANON_KEY = "..."
SUPABASE_BUCKET = "nai-images"             # 웹앱 .env의 VITE_SUPABASE_BUCKET과 동일하게
```

`.docx` 파일과 `serviceAccountKey.json` 파일을 이 폴더 안에 함께 넣어주세요.

### 5-2. `.docx` 표 형식

지금 스크립트는 **표 안의 모든 텍스트 셀**을 태그명으로 읽습니다. (이미지만 있는 셀은
텍스트가 없으므로 자동으로 무시됩니다.) 표에 태그 외 다른 텍스트가 섞여 있으면 잘못
읽힐 수 있으니, 실행 직후 출력되는 태그 목록을 먼저 확인하세요.

### 5-3. 실행

```bash
python upload_tags.py
```

태그 하나당 이미지 3장을 생성/업로드하므로, 태그 개수가 많으면 시간이 꽤 걸립니다.
중간에 특정 태그가 실패해도 스크립트는 멈추지 않고 다음 태그로 계속 진행합니다.
다만 계속 실패만 하는 경우, `Ctrl`+`C`로 실행을 멈추고 파일을 AI에게 보내 도움을 청하는 등의 조치를 취해주세요.

### 5-4. 비용 안내

NovelAI 이미지 생성은 계정의 Anlas(크레딧)를 소모할 수 있습니다. (Opus 등 무제한 요금제는
스텝/해상도/배치 조건을 만족하면 무료지만, 조건을 벗어나면 소모될 수 있습니다.) 실행 전
본인 계정의 크레딧 상태를 확인하시길 권장합니다.

---

## 6. 자주 발생할 수 있는 문제

- **`.docx`에서 태그를 하나도 못 찾아요** → 표 구조가 예상과 다를 수 있어요. 실행 후
  출력되는 태그 목록을 먼저 확인하세요.
- **NAI API 에러 (401/403)** → 토큰이 만료됐거나 잘못 복사됐을 수 있어요. 새로 발급받아
  보세요.
- **NAI API 에러 (500)** → 요청 형식 문제일 수 있습니다. 에러 메시지에 서버가 실제로
  뭐라고 답했는지 함께 출력되니, 그 내용을 참고하세요.
- **Supabase 업로드 실패** → 버킷 이름이 웹앱 `.env`의 `VITE_SUPABASE_BUCKET`과 동일한지,
  버킷이 **Public**으로 설정되어 있는지 확인하세요.
- **Firestore 저장 실패 (permission-denied)** → 서비스 계정 키는 Firestore 보안 규칙을
  우회하므로 이 에러는 잘 나지 않지만, 혹시 뜬다면 키 파일 경로가 정확한지 확인하세요.
- **크레딧(Anlas) 관련 에러** → NovelAI 계정의 이미지 생성 크레딧이 부족한 경우입니다.

---

## 8. 기여 / 문의

버그 제보나 개선 제안은 would.ikuzo@gmail.com으로 남겨주세요. 상업적 이용이나 서비스 형태
운영을 원하시면 위 이메일을 통해 먼저 연락해주세요.
