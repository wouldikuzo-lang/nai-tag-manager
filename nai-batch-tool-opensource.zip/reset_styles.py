"""
작가 태그(artistTags) 화품 분류(styles) 일괄 초기화 스크립트
============================================================

Firestore의 artistTags 컬렉션에 있는 모든 문서에서, 'styles' 필드만 빈 배열([])로
초기화합니다. 태그 이름, 예시 이미지, 메모 등 다른 데이터는 전혀 건드리지 않습니다.

⚠️ 이 작업은 되돌릴 수 없습니다. 실행 전에 정말 화품 분류를 전부 지우려는 게 맞는지
   한 번 더 확인해주세요.

사용 전 아래 "설정값" 부분을 반드시 채워주세요.
"""

import json
from pathlib import Path

import firebase_admin
from firebase_admin import credentials, firestore

# ============================================================
# 설정값 — 여기를 본인 환경에 맞게 채워주세요
# ============================================================

# Firebase 서비스 계정 키 (.json) 파일 경로
SERVICE_ACCOUNT_PATH = "serviceAccountKey.json"

# 초기화할 컬렉션 이름 (작가 태그만 지우려면 이대로 두면 됨)
COLLECTION_NAME = "artistTags"

# ============================================================
# 여기부터는 수정하지 않아도 됩니다
# ============================================================


def main():
    print("[1/2] Firebase 연결 중...")
    if not Path(SERVICE_ACCOUNT_PATH).exists():
        print(f"      ! 서비스 계정 키 파일을 찾을 수 없습니다: {SERVICE_ACCOUNT_PATH}")
        return

    with open(SERVICE_ACCOUNT_PATH, "r", encoding="utf-8") as f:
        sa_data = json.load(f)
    project_id = sa_data.get("project_id")

    cred = credentials.Certificate(SERVICE_ACCOUNT_PATH)
    firebase_admin.initialize_app(cred, {"projectId": project_id})
    db = firestore.client()
    print(f"      -> 연결 완료 (project: {project_id})")

    docs = list(db.collection(COLLECTION_NAME).stream())
    print(f"\n총 {len(docs)}개 문서를 찾았습니다.")

    if not docs:
        print("초기화할 문서가 없습니다.")
        return

    confirm = input(
        f"\n'{COLLECTION_NAME}' 컬렉션의 {len(docs)}개 문서에서 화품 분류(styles)를 "
        f"전부 비웁니다. 계속할까요? (y/N): "
    )
    if confirm.strip().lower() != "y":
        print("취소되었습니다. 아무것도 바뀌지 않았습니다.")
        return

    print("\n[2/2] 초기화 진행 중...\n")

    # 500개씩 배치로 처리 (Firestore 배치 쓰기 한도)
    BATCH_SIZE = 400
    updated = 0

    for i in range(0, len(docs), BATCH_SIZE):
        batch = db.batch()
        chunk = docs[i : i + BATCH_SIZE]
        for doc in chunk:
            batch.update(doc.reference, {"styles": []})
        batch.commit()
        updated += len(chunk)
        print(f"  {updated}/{len(docs)}개 처리 완료")

    print(f"\n완료! 총 {updated}개 문서의 화품 분류를 초기화했습니다.")


if __name__ == "__main__":
    main()
