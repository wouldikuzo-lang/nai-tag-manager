import { useState } from 'react'

export default function BulkActionBar({
  count,
  allStyles,
  onAddStyle,
  onSetFavorite,
  onDelete,
  onCancel,
}) {
  const [showStyleInput, setShowStyleInput] = useState(false)
  const [styleValue, setStyleValue] = useState('')

  const suggestions = allStyles.filter(
    (s) => styleValue && s.toLowerCase().includes(styleValue.toLowerCase())
  )

  const submitStyle = (value) => {
    const v = (value ?? styleValue).trim()
    if (!v) return
    onAddStyle(v)
    setStyleValue('')
    setShowStyleInput(false)
  }

  return (
    <div className="bulk-action-bar">
      <span className="bulk-count">{count}개 선택됨</span>

      <div className="bulk-actions">
        {showStyleInput ? (
          <div className="bulk-style-input-wrap">
            <input
              className="text-input bulk-style-input"
              type="text"
              autoFocus
              placeholder="추가할 화풍/분류 태그"
              value={styleValue}
              onChange={(e) => setStyleValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  submitStyle()
                } else if (e.key === 'Escape') {
                  setShowStyleInput(false)
                  setStyleValue('')
                }
              }}
            />
            {suggestions.length > 0 && (
              <div className="style-suggestions">
                {suggestions.slice(0, 6).map((s) => (
                  <button
                    key={s}
                    type="button"
                    className="style-suggestion-chip"
                    onClick={() => submitStyle(s)}
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
            <button type="button" className="btn-primary btn-tiny" onClick={() => submitStyle()}>
              추가
            </button>
            <button
              type="button"
              className="btn-secondary btn-tiny"
              onClick={() => {
                setShowStyleInput(false)
                setStyleValue('')
              }}
            >
              취소
            </button>
          </div>
        ) : (
          <button
            type="button"
            className="btn-secondary btn-tiny"
            onClick={() => setShowStyleInput(true)}
          >
            태그 추가
          </button>
        )}

        <button type="button" className="btn-secondary btn-tiny" onClick={() => onSetFavorite(true)}>
          즐겨찾기 등록
        </button>
        <button type="button" className="btn-secondary btn-tiny" onClick={() => onSetFavorite(false)}>
          즐겨찾기 해제
        </button>
        <button type="button" className="delete-btn btn-tiny" onClick={onDelete}>
          일괄 삭제
        </button>
      </div>

      <button type="button" className="bulk-cancel" onClick={onCancel}>
        선택 취소
      </button>
    </div>
  )
}
