import { useState, useEffect } from 'react'
import StyleAndSlotsFields from './StyleAndSlotsFields'

const emptySlots = () => ({
  girl: { url: '', label: 'girl' },
  boy: { url: '', label: 'boy' },
  none: { url: '', label: '빈프롬' },
})

const SAMPLERS = [
  'Euler Ancestral',
  'Euler',
  'DPM++ 2S Ancestral',
  'DPM++ 2M SDE',
  'DPM++ 2M',
  'DPM++ SDE',
]

const NOISE_SCHEDULES = ['karras', 'exponential', 'polyexponential']

const clamp = (v, min, max) => Math.min(max, Math.max(min, v))

export default function ComboEditorModal({ initial, existingStyles, onSave, onClose }) {
  const [name, setName] = useState(initial?.name || '')
  const [mainPrompt, setMainPrompt] = useState(initial?.mainPrompt || '')
  const [negativePrompt, setNegativePrompt] = useState(initial?.negativePrompt || '')
  const [steps, setSteps] = useState(initial?.settings?.steps ?? 28)
  const [promptGuidance, setPromptGuidance] = useState(initial?.settings?.promptGuidance ?? 5.0)
  const [sampler, setSampler] = useState(initial?.settings?.sampler ?? SAMPLERS[0])
  const [rescale, setRescale] = useState(initial?.settings?.rescale ?? 0.0)
  const [noiseSchedule, setNoiseSchedule] = useState(
    initial?.settings?.noiseSchedule ?? NOISE_SCHEDULES[0]
  )
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [styles, setStyles] = useState(initial?.styles || [])
  const [styleInput, setStyleInput] = useState('')
  const [slots, setSlots] = useState(initial?.slots || emptySlots())
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const addStyle = () => {
    const v = styleInput.trim()
    if (v && !styles.includes(v)) setStyles([...styles, v])
    setStyleInput('')
  }
  const removeStyle = (s) => setStyles(styles.filter((x) => x !== s))
  const updateSlotUrl = (key, url) => {
    setSlots((prev) => ({ ...prev, [key]: { ...prev[key], url } }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (saving) return
    setSaving(true)
    try {
      await onSave({
        name: name.trim(),
        mainPrompt: mainPrompt.trim(),
        negativePrompt: negativePrompt.trim(),
        settings: {
          steps: clamp(Number(steps) || 0, 1, 50),
          promptGuidance: clamp(Math.round((Number(promptGuidance) || 0) * 10) / 10, 0, 10),
          sampler,
          rescale: clamp(Math.round((Number(rescale) || 0) * 100) / 100, 0, 1),
          noiseSchedule,
        },
        styles,
        slots,
      })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{initial ? '그깍 수정' : '새 그깍 추가'}</h2>
          <button className="modal-close" onClick={onClose} aria-label="닫기" type="button">
            ×
          </button>
        </div>

        <form className="modal-form" onSubmit={handleSubmit}>
          <section className="form-section">
            <label className="form-label">이름 (선택)</label>
            <input
              className="text-input"
              type="text"
              placeholder="선택"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </section>

          <section className="form-section">
            <label className="form-label">메인 프롬프트 (작가 태그 조합)</label>
            <textarea
              className="text-input textarea mono"
              placeholder="artist:a, artist:b, artist:c ..."
              value={mainPrompt}
              onChange={(e) => setMainPrompt(e.target.value)}
              rows={3}
            />
          </section>

          <section className="form-section">
            <label className="form-label">부정 프롬프트</label>
            <textarea
              className="text-input textarea mono"
              placeholder="제외하고 싶은 요소를 입력하세요"
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              rows={2}
            />
          </section>

          <section className="form-section">
            <label className="form-label">설정</label>
            <div className="settings-grid">
              <div className="setting-field">
                <label htmlFor="steps">Steps (1~50)</label>
                <input
                  id="steps"
                  className="text-input"
                  type="number"
                  min={1}
                  max={50}
                  step={1}
                  value={steps}
                  onChange={(e) => setSteps(e.target.value)}
                />
              </div>
              <div className="setting-field">
                <label htmlFor="guidance">Prompt Guidance (0~10)</label>
                <input
                  id="guidance"
                  className="text-input"
                  type="number"
                  min={0}
                  max={10}
                  step={0.1}
                  value={promptGuidance}
                  onChange={(e) => setPromptGuidance(e.target.value)}
                />
              </div>
              <div className="setting-field setting-field--wide">
                <label htmlFor="sampler">Sampler</label>
                <select
                  id="sampler"
                  className="text-input"
                  value={sampler}
                  onChange={(e) => setSampler(e.target.value)}
                >
                  {SAMPLERS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </section>

          <section className="form-section">
            <button
              type="button"
              className="advanced-toggle"
              onClick={() => setShowAdvanced((v) => !v)}
            >
              <span>Advanced Settings</span>
              <span className={`chevron ${showAdvanced ? 'is-open' : ''}`}>⌄</span>
            </button>
            {showAdvanced && (
              <div className="settings-grid">
                <div className="setting-field">
                  <label htmlFor="rescale">Prompt Guidance Rescale (0~1)</label>
                  <input
                    id="rescale"
                    className="text-input"
                    type="number"
                    min={0}
                    max={1}
                    step={0.01}
                    value={rescale}
                    onChange={(e) => setRescale(e.target.value)}
                  />
                </div>
                <div className="setting-field setting-field--wide">
                  <label htmlFor="noise">Noise Schedule</label>
                  <select
                    id="noise"
                    className="text-input"
                    value={noiseSchedule}
                    onChange={(e) => setNoiseSchedule(e.target.value)}
                  >
                    {NOISE_SCHEDULES.map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}
          </section>

          <StyleAndSlotsFields
            styles={styles}
            styleInput={styleInput}
            onStyleInputChange={setStyleInput}
            onAddStyle={addStyle}
            onRemoveStyle={removeStyle}
            onPickSuggestion={(s) => {
              setStyles([...styles, s])
              setStyleInput('')
            }}
            existingStyles={existingStyles}
            slots={slots}
            onSlotUrlChange={updateSlotUrl}
          />

          <div className="modal-actions">
            <button type="button" className="btn-secondary" onClick={onClose} disabled={saving}>
              취소
            </button>
            <button type="submit" className="btn-primary" disabled={saving}>
              {saving ? '저장 중...' : '저장'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
