import { useState, useRef, useEffect } from 'react'

/**
 * 화면(뷰포트)에 실제로 들어오기 전까지는 이미지를 아예 요청하지 않습니다.
 * 브라우저 기본 loading="lazy"보다 더 공격적으로 동작해서, 카드 수백 개가
 * 한 페이지에 있어도 초기 로딩 트래픽을 크게 줄여줍니다.
 */
export default function LazyImage({ src, alt, className }) {
  const [isVisible, setIsVisible] = useState(false)
  const [isLoaded, setIsLoaded] = useState(false)
  const containerRef = useRef(null)

  useEffect(() => {
    if (!src) return
    const el = containerRef.current
    if (!el) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      {
        // 화면에 실제로 보이기 약 300px 전에 미리 로딩 시작 (스크롤하다 빈 화면 보이는 것 방지)
        rootMargin: '300px 0px',
        threshold: 0.01,
      }
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [src])

  return (
    <div ref={containerRef} className={`lazy-image-wrap ${className || ''}`}>
      {isVisible && (
        <img
          src={src}
          alt={alt}
          loading="lazy"
          onLoad={() => setIsLoaded(true)}
          className={`lazy-image ${isLoaded ? 'is-loaded' : ''}`}
        />
      )}
      {!isLoaded && <div className="lazy-image-skeleton" aria-hidden="true" />}
    </div>
  )
}
