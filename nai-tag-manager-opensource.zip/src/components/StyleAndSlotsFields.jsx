import SlotCarousel from './SlotCarousel'

export default function StyleAndSlotsFields({
  styles,
  styleInput,
  onStyleInputChange,
  onAddStyle,
  onRemoveStyle,
  onPickSuggestion,
  existingStyles,
  slots,
  onSlotUrlChange,
}) {
  const suggestions = existingStyles.filter(
    (s) => s.toLowerCase().includes(styleInput.toLowerCase()) && !styles.includes(s)
  )

  return (
    <>
      <section className="form-section">
        <label className="form-label">화풍 / 분류</label>
        <div className="style-input-row">
          <input
            className="text-input"
            type="text"
            placeholder="분류 태그 입력 후 Enter"
            value={styleInput}
            onChange={(e) => onStyleInputChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault()
                onAddStyle()
              }
            }}
          />
          <button type="button" className="add-style-btn" onClick={onAddStyle}>
            추가
          </button>
        </div>
        {suggestions.length > 0 && styleInput && (
          <div className="style-suggestions">
            {suggestions.slice(0, 6).map((s) => (
              <button
                key={s}
                type="button"
                className="style-suggestion-chip"
                onClick={() => onPickSuggestion(s)}
              >
                {s}
              </button>
            ))}
          </div>
        )}
        {styles.length > 0 && (
          <div className="tag-style-chips">
            {styles.map((s) => (
              <span key={s} className="style-chip style-chip--removable">
                {s}
                <button type="button" onClick={() => onRemoveStyle(s)} aria-label={`${s} 제거`}>
                  ×
                </button>
              </span>
            ))}
          </div>
        )}
      </section>

      <section className="form-section">
        <label className="form-label">예시 이미지 (girl / boy / 빈프롬)</label>
        <SlotCarousel slots={slots} editable onSlotUrlChange={onSlotUrlChange} />
      </section>
    </>
  )
}
