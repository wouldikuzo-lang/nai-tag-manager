import { useState } from 'react'
import SlotCarousel from './SlotCarousel'

export default function TagCard({
  tag,
  globalFilter,
  onToggleFavorite,
  onEdit,
  onDelete,
  selectionMode = false,
  selected = false,
  onToggleSelect,
}) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(tag.name)
      setCopied(true)
      setTimeout(() => setCopied(false), 1200)
    } catch {
      // clipboard unavailable — silently ignore
    }
  }

  return (
    <article
      className={`tag-card ${selectionMode ? 'is-selectable' : ''} ${selected ? 'is-selected' : ''}`}
      onClick={selectionMode ? () => onToggleSelect(tag.id) : undefined}
    >
      {selectionMode && (
        <label className="card-select-check" onClick={(e) => e.stopPropagation()}>
          <input
            type="checkbox"
            checked={selected}
            onChange={() => onToggleSelect(tag.id)}
            aria-label={`${tag.name} 선택`}
          />
        </label>
      )}
      <SlotCarousel slots={tag.slots} globalFilter={globalFilter} editable={false} />

      <div className="tag-card-body">
        <div className="tag-name-row">
          <span className="tag-name" title={tag.name}>
            {tag.name}
          </span>
          <button
            className={`copy-btn ${copied ? 'is-copied' : ''}`}
            onClick={(e) => {
              e.stopPropagation()
              handleCopy()
            }}
            aria-label="태그 복사"
            type="button"
          >
            {copied ? (
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path
                  d="M20 6L9 17l-5-5"
                  stroke="currentColor"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            ) : (
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <rect
                  x="9"
                  y="9"
                  width="12"
                  height="12"
                  rx="2"
                  stroke="currentColor"
                  strokeWidth="1.8"
                />
                <path
                  d="M5 15V5a2 2 0 0 1 2-2h10"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                />
              </svg>
            )}
          </button>
        </div>

        {tag.styles?.length > 0 && (
          <div className="tag-style-chips">
            {tag.styles.map((s) => (
              <span key={s} className="style-chip">
                {s}
              </span>
            ))}
          </div>
        )}

        {tag.memo && <p className="tag-memo">{tag.memo}</p>}

        {!selectionMode && (
          <div className="tag-actions">
            <button
              className={`fav-btn ${tag.favorite ? 'is-fav' : ''}`}
              onClick={() => onToggleFavorite(tag.id, tag.favorite)}
              aria-label={tag.favorite ? '즐겨찾기 해제' : '즐겨찾기 추가'}
              type="button"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill={tag.favorite ? 'currentColor' : 'none'}>
                <path
                  d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
            <button className="edit-btn" onClick={() => onEdit(tag)} type="button">
              수정
            </button>
            <button className="delete-btn" onClick={() => onDelete(tag)} type="button">
              삭제
            </button>
          </div>
        )}
      </div>
    </article>
  )
}
