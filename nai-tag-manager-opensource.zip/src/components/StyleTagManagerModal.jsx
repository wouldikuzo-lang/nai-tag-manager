import { useState } from 'react'

export default function StyleTagManagerModal({ styleTags, onAdd, onRename, onDelete, onClose }) {
  const [newName, setNewName] = useState('')
  const [error, setError] = useState('')
  const [editingId, setEditingId] = useState(null) // null | 'new' | tag key
  const [editingValue, setEditingValue] = useState('')
  const [confirmingTarget, setConfirmingTarget] = useState(null)
  const [busy, setBusy] = useState(false)

  const keyOf = (tag) => tag.id || `unregistered:${tag.name}`

  const handleAdd = async (e) => {
    e.preventDefault()
    if (!newName.trim() || busy) return
    setBusy(true)
    setError('')
    const result = await onAdd(newName)
    setBusy(false)
    if (result?.success) {
      setNewName('')
    } else {
      setError(result?.reason || '추가에 실패했습니다.')
    }
  }

  const startEdit = (tag) => {
    setEditingId(keyOf(tag))
    setEditingValue(tag.name)
    setError('')
  }

  const cancelEdit = () => {
    setEditingId(null)
    setEditingValue('')
  }

  const submitEdit = async (tag) => {
    if (busy) return
    if (!editingValue.trim() || editingValue.trim() === tag.name) {
      cancelEdit()
      return
    }
    setBusy(true)
    const result = await onRename(tag, editingValue)
    setBusy(false)
    if (result?.success) {
      cancelEdit()
    } else {
      setError(result?.reason || '변경에 실패했습니다.')
    }
  }

  const confirmDelete = async () => {
    if (!confirmingTarget || busy) return
    setBusy(true)
    await onDelete(confirmingTarget)
    setBusy(false)
    setConfirmingTarget(null)
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>화풍 / 분류 태그 관리</h2>
          <button className="modal-close" onClick={onClose} aria-label="닫기" type="button">
            ×
          </button>
        </div>

        <div className="modal-form">
          <section className="form-section">
            <label className="form-label">새 태그 추가</label>
            <form className="style-input-row" onSubmit={handleAdd}>
              <input
                className="text-input"
                type="text"
                placeholder="새 화풍/분류 이름"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                disabled={busy}
              />
              <button type="submit" className="add-style-btn" disabled={busy || !newName.trim()}>
                추가
              </button>
            </form>
            {error && <p className="style-manager-error">{error}</p>}
          </section>

          <section className="form-section">
            <label className="form-label">
              전체 태그 ({styleTags.length}개) — 이름을 바꾸거나 지우면 이 태그가 붙은 모든
              카드에도 함께 반영됩니다.
            </label>

            {styleTags.length === 0 ? (
              <p className="style-manager-empty">아직 등록된 화풍/분류 태그가 없습니다.</p>
            ) : (
              <ul className="style-manager-list">
                {styleTags.map((tag) => {
                  const key = keyOf(tag)
                  const isEditing = editingId === key
                  return (
                    <li key={key} className="style-manager-row">
                      {isEditing ? (
                        <input
                          className="text-input style-manager-edit-input"
                          type="text"
                          autoFocus
                          value={editingValue}
                          onChange={(e) => setEditingValue(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault()
                              submitEdit(tag)
                            } else if (e.key === 'Escape') {
                              cancelEdit()
                            }
                          }}
                          disabled={busy}
                        />
                      ) : (
                        <span className="style-manager-name">
                          {tag.name}
                          <span className="style-manager-count">{tag.count}개 카드</span>
                        </span>
                      )}

                      <div className="style-manager-actions">
                        {isEditing ? (
                          <>
                            <button
                              type="button"
                              className="btn-secondary btn-tiny"
                              onClick={cancelEdit}
                              disabled={busy}
                            >
                              취소
                            </button>
                            <button
                              type="button"
                              className="btn-primary btn-tiny"
                              onClick={() => submitEdit(tag)}
                              disabled={busy}
                            >
                              완료
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              type="button"
                              className="btn-secondary btn-tiny"
                              onClick={() => startEdit(tag)}
                              disabled={busy}
                            >
                              수정
                            </button>
                            <button
                              type="button"
                              className="delete-btn btn-tiny"
                              onClick={() => setConfirmingTarget(tag)}
                              disabled={busy}
                            >
                              삭제
                            </button>
                          </>
                        )}
                      </div>
                    </li>
                  )
                })}
              </ul>
            )}
          </section>

          <div className="modal-actions">
            <button type="button" className="btn-primary" onClick={onClose}>
              닫기
            </button>
          </div>
        </div>
      </div>

      {confirmingTarget && (
        <div className="modal-backdrop" onClick={() => setConfirmingTarget(null)}>
          <div className="confirm-panel" onClick={(e) => e.stopPropagation()}>
            <p>
              "{confirmingTarget.name}" 태그를 삭제할까요?
              <br />
              이 태그가 붙어있던 {confirmingTarget.count}개 카드에서도 함께 제거됩니다.
            </p>
            <div className="modal-actions">
              <button
                type="button"
                className="btn-secondary"
                onClick={() => setConfirmingTarget(null)}
                disabled={busy}
              >
                취소
              </button>
              <button type="button" className="delete-btn" onClick={confirmDelete} disabled={busy}>
                삭제
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
