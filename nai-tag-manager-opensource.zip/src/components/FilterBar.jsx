import SortControl from './SortControl'

export default function FilterBar({
  search,
  onSearchChange,
  allStyles,
  activeStyles,
  onToggleStyle,
  globalFilter,
  onGlobalFilterChange,
  favoritesOnly,
  onToggleFavoritesOnly,
  sortMode,
  onSortModeChange,
}) {
  return (
    <div className="filter-bar">
      <div className="filter-row">
        <div className="search-box">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
            <path d="M21 21l-4.3-4.3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <input
            type="text"
            placeholder="작가 태그 검색..."
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>

        <SortControl value={sortMode} onChange={onSortModeChange} />

        <button
          className={`fav-filter-btn ${favoritesOnly ? 'is-active' : ''}`}
          onClick={onToggleFavoritesOnly}
          type="button"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill={favoritesOnly ? 'currentColor' : 'none'}>
            <path
              d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinejoin="round"
            />
          </svg>
          즐겨찾기만
        </button>

        <div className="global-slot-toggle" role="group" aria-label="예시 이미지 전역 필터">
          {[
            { key: 'all', label: '전체' },
            { key: 'girl', label: 'girl' },
            { key: 'boy', label: 'boy' },
            { key: 'none', label: '빈프롬' },
          ].map((opt) => (
            <button
              key={opt.key}
              className={`slot-toggle-btn ${globalFilter === opt.key ? 'is-active' : ''}`}
              onClick={() => onGlobalFilterChange(opt.key)}
              type="button"
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {allStyles.length > 0 && (
        <div className="style-filter-row">
          {allStyles.map((s) => (
            <button
              key={s}
              className={`style-filter-chip ${activeStyles.includes(s) ? 'is-active' : ''}`}
              onClick={() => onToggleStyle(s)}
              type="button"
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
