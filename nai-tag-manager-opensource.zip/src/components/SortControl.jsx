const SORT_OPTIONS = [
  { key: 'newest', label: '최신순' },
  { key: 'oldest', label: '오래된순' },
  { key: 'alpha', label: '알파벳순' },
  { key: 'custom', label: '기타 (직접 정렬)' },
]

export default function SortControl({ value, onChange }) {
  return (
    <div className="sort-control">
      <label htmlFor="sort-select" className="sort-label">
        정렬
      </label>
      <select
        id="sort-select"
        className="sort-select"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {SORT_OPTIONS.map((opt) => (
          <option key={opt.key} value={opt.key}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  )
}
