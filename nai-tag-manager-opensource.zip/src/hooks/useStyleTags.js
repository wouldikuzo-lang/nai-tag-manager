import { useEffect, useState, useCallback } from 'react'
import {
  collection,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  query,
  orderBy,
  writeBatch,
} from 'firebase/firestore'
import { db } from '../lib/firebase'

/**
 * 화풍/분류 태그(styleTags 컬렉션)를 작가 태그·그깍 카드와 별개로 관리하는 훅.
 *
 * - styleTags 컬렉션에 정식으로 등록된 태그 + 기존 카드에서만 쓰이고 있는 "미등록" 태그를
 *   합쳐서 하나의 목록으로 보여줍니다.
 * - 이름 변경/삭제 시 artistTags, combos 두 컬렉션에 걸쳐 있는 모든 카드의 styles 배열도
 *   함께 갱신합니다 (카드를 하나하나 열어서 고치지 않아도 되도록).
 */
export function useStyleTags(user, tagItems, comboItems) {
  const [docs, setDocs] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user || !db) {
      setDocs([])
      setLoading(false)
      return
    }
    setLoading(true)
    const q = query(collection(db, 'styleTags'), orderBy('createdAt', 'asc'))
    const unsub = onSnapshot(
      q,
      (snapshot) => {
        setDocs(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })))
        setLoading(false)
      },
      (err) => {
        console.error(err)
        setLoading(false)
      }
    )
    return () => unsub()
  }, [user])

  // 카드에서만 쓰이고 styleTags 컬렉션에는 없는 "미등록" 이름들도 목록에 합쳐서 보여줌
  const usageCount = {}
  ;[...tagItems, ...comboItems].forEach((it) => {
    it.styles?.forEach((s) => {
      usageCount[s] = (usageCount[s] || 0) + 1
    })
  })

  const registeredNames = new Set(docs.map((d) => d.name))
  const unregistered = Object.keys(usageCount)
    .filter((name) => !registeredNames.has(name))
    .sort((a, b) => a.localeCompare(b, 'ko'))
    .map((name) => ({ id: null, name }))

  const allStyleTags = [...docs, ...unregistered].map((d) => ({
    ...d,
    count: usageCount[d.name] || 0,
  }))

  const addStyleTag = useCallback(
    async (name) => {
      const v = name.trim()
      if (!v) return { success: false, reason: '이름을 입력해주세요.' }
      if (allStyleTags.some((s) => s.name === v)) {
        return { success: false, reason: '이미 있는 태그예요.' }
      }
      await addDoc(collection(db, 'styleTags'), { name: v, createdAt: serverTimestamp() })
      return { success: true }
    },
    [allStyleTags]
  )

  // 두 컬렉션에 걸쳐 styles 배열 안의 이름을 바꾸거나 지우는 배치 작업
  const applyToCards = useCallback(async (transform) => {
    const batch = writeBatch(db)
    let touched = false
    for (const [collectionName, list] of [
      ['artistTags', tagItems],
      ['combos', comboItems],
    ]) {
      for (const item of list) {
        if (!item.styles?.length) continue
        const nextStyles = transform(item.styles)
        if (nextStyles === item.styles) continue // 변경 없음
        batch.update(doc(db, collectionName, item.id), { styles: nextStyles })
        touched = true
      }
    }
    if (touched) await batch.commit()
  }, [tagItems, comboItems])

  const renameStyleTag = useCallback(
    async (tag, newName) => {
      const v = newName.trim()
      if (!v || v === tag.name) return { success: false }
      if (allStyleTags.some((s) => s.name === v)) {
        return { success: false, reason: '이미 있는 태그 이름이에요.' }
      }
      if (tag.id) {
        await updateDoc(doc(db, 'styleTags', tag.id), { name: v })
      } else {
        // 미등록 태그였다면 이번 기회에 정식으로 등록
        await addDoc(collection(db, 'styleTags'), { name: v, createdAt: serverTimestamp() })
      }
      await applyToCards((styles) =>
        styles.includes(tag.name) ? styles.map((s) => (s === tag.name ? v : s)) : styles
      )
      return { success: true }
    },
    [allStyleTags, applyToCards]
  )

  const deleteStyleTag = useCallback(
    async (tag) => {
      if (tag.id) {
        await deleteDoc(doc(db, 'styleTags', tag.id))
      }
      await applyToCards((styles) =>
        styles.includes(tag.name) ? styles.filter((s) => s !== tag.name) : styles
      )
    },
    [applyToCards]
  )

  return {
    styleTags: allStyleTags,
    loading,
    addStyleTag,
    renameStyleTag,
    deleteStyleTag,
  }
}
