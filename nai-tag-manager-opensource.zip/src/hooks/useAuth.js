import { useEffect, useState, useCallback } from 'react'
import { onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth'
import { auth, googleProvider, allowedEmails, firebaseConfigured } from '../lib/firebase'

export function useAuth() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [deniedEmail, setDeniedEmail] = useState(null)

  useEffect(() => {
    if (!firebaseConfigured) {
      setLoading(false)
      return
    }
    const unsub = onAuthStateChanged(auth, (u) => {
      if (u) {
        const email = (u.email || '').toLowerCase()
        const isAllowed = allowedEmails.length === 0 || allowedEmails.includes(email)
        if (isAllowed) {
          setUser(u)
          setDeniedEmail(null)
        } else {
          setDeniedEmail(u.email)
          signOut(auth)
          setUser(null)
        }
      } else {
        setUser(null)
      }
      setLoading(false)
    })
    return () => unsub()
  }, [])

  const login = useCallback(async () => {
    if (!firebaseConfigured) return
    await signInWithPopup(auth, googleProvider)
  }, [])

  const logout = useCallback(async () => {
    if (!firebaseConfigured) return
    await signOut(auth)
  }, [])

  return { user, loading, login, logout, deniedEmail, firebaseConfigured }
}
