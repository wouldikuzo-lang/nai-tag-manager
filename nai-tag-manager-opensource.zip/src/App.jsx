import { useMemo, useState, useCallback, useEffect, useRef, useLayoutEffect } from 'react'
import { useAuth } from './hooks/useAuth'
import { useCollection } from './hooks/useCollection'
import { useStyleTags } from './hooks/useStyleTags'
import LoginScreen from './components/LoginScreen'
import FilterBar from './components/FilterBar'
import TagCard from './components/TagCard'
import ComboCard from './components/ComboCard'
import TagEditorModal from './components/TagEditorModal'
import ComboEditorModal from './components/ComboEditorModal'
import ConfirmModal from './components/ConfirmModal'
import SortableGrid from './components/SortableGrid'
import BulkActionBar from './components/BulkActionBar'
import StyleTagManagerModal from './components/StyleTagManagerModal'

const emptySlots = () => ({
  girl: { url: '', label: 'girl' },
  boy: { url: '', label: 'boy' },
  none: { url: '', label: '빈프롬' },
})

function sortItems(items, sortMode) {
  const rows = [...items]
  if (sortMode === 'newest') {
    rows.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))
  } else if (sortMode === 'oldest') {
    rows.sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0))
  } else if (sortMode === 'alpha') {
    rows.sort((a, b) => (a.name || '').localeCompare(b.name || '', 'ko'))
  } else if (sortMode === 'custom') {
    rows.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))
  }
  // favorites always pinned to top within the chosen order
  return rows.sort((a, b) => (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0))
}

// 삭제 확인창 등에 보여줄 표시용 이름 (이름 없는 그깍 대비)
function displayName(item, tab) {
  if (item.name?.trim()) return item.name
  if (tab === 'combos' && item.mainPrompt?.trim()) {
    return item.mainPrompt.trim().slice(0, 24) + (item.mainPrompt.trim().length > 24 ? '…' : '')
  }
  return '(이름 없음)'
}

export default function App() {
  const { user, loading: authLoading, login, logout, deniedEmail, firebaseConfigured } = useAuth()

  const tagsCol = useCollection(user, 'artistTags', (data) => ({
    name: data.name || '',
    styles: data.styles || [],
    slots: data.slots || emptySlots(),
    memo: data.memo || '',
  }))

  const combosCol = useCollection(user, 'combos', (data) => ({
    name: data.name || '',
    mainPrompt: data.mainPrompt || '',
    negativePrompt: data.negativePrompt || '',
    settings: data.settings || {},
    styles: data.styles || [],
    slots: data.slots || emptySlots(),
  }))

  const styleTagsCtl = useStyleTags(user, tagsCol.items, combosCol.items)

  const [activeTab, setActiveTab] = useState('tags') // 'tags' | 'combos'
  const [search, setSearch] = useState('')
  const [activeStyles, setActiveStyles] = useState([])
  const [globalFilter, setGlobalFilter] = useState('all')
  const [favoritesOnly, setFavoritesOnly] = useState(false)
  const [sortMode, setSortMode] = useState('newest')
  const [editingItem, setEditingItem] = useState(null)
  const [showEditor, setShowEditor] = useState(false)
  const [pendingDelete, setPendingDelete] = useState(null)
  const [showStyleManager, setShowStyleManager] = useState(false)

  // ---- 선택 모드 (일괄 작업) ----
  const [selectionMode, setSelectionMode] = useState(false)
  const [selectedIds, setSelectedIds] = useState(() => new Set())
  const [pendingBulkDelete, setPendingBulkDelete] = useState(false)

  const currentCol = activeTab === 'tags' ? tagsCol : combosCol
  const {
    items,
    loading: itemsLoading,
    addItem,
    updateItem,
    deleteItem,
    toggleFavorite,
    persistOrder,
    batchDelete,
    batchSetFavorite,
    batchAddStyle,
  } = currentCol

  // switching tabs resets filters that don't make sense to carry over
  const switchTab = (tab) => {
    setActiveTab(tab)
    setSearch('')
    setActiveStyles([])
    setFavoritesOnly(false)
    setSortMode('newest')
    setSelectionMode(false)
    setSelectedIds(new Set())
  }

  const allStyles = useMemo(() => {
    const set = new Set()
    items.forEach((t) => t.styles?.forEach((s) => set.add(s)))
    return Array.from(set).sort()
  }, [items])

  // 화풍 태그가 이름 변경/삭제 등으로 사라졌는데 필터에는 남아있어서
  // 목록이 영영 빈 채로 남는 것을 막기 위한 안전장치
  useEffect(() => {
    setActiveStyles((prev) => {
      const next = prev.filter((s) => allStyles.includes(s))
      return next.length === prev.length ? prev : next
    })
  }, [allStyles])

  const toggleStyleFilter = (s) => {
    setActiveStyles((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]))
  }

  const filteredItems = useMemo(() => {
    let rows = items
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      rows = rows.filter((t) => (t.name || '').toLowerCase().includes(q))
    }
    if (activeStyles.length > 0) {
      rows = rows.filter((t) => activeStyles.every((s) => t.styles?.includes(s)))
    }
    if (favoritesOnly) {
      rows = rows.filter((t) => t.favorite)
    }
    return sortItems(rows, sortMode)
  }, [items, search, activeStyles, favoritesOnly, sortMode])

  const isCustomOrderActive =
    sortMode === 'custom' && !search.trim() && activeStyles.length === 0 && !favoritesOnly

  const handleReorder = useCallback(
    (reordered) => {
      persistOrder(reordered.map((it) => it.id))
    },
    [persistOrder]
  )

  const openNew = () => {
    setEditingItem(null)
    setShowEditor(true)
  }
  const openEdit = (item) => {
    setEditingItem(item)
    setShowEditor(true)
  }

  const handleSave = async (data) => {
    if (editingItem) {
      await updateItem(editingItem.id, data)
    } else {
      await addItem(data)
    }
    setShowEditor(false)
    setEditingItem(null)
  }

  const handleDeleteConfirmed = async () => {
    if (pendingDelete) {
      await deleteItem(pendingDelete.id)
      setPendingDelete(null)
    }
  }

  // ---- 스크롤 위치 유지 ----
  // 1) 즐겨찾기 토글 등으로 목록 순서가 바뀌어도 화면이 튀지 않도록,
  //    다시 그려지기 직전(paint 전)에 이전 스크롤 위치로 되돌립니다.
  const scrollRestoreRef = useRef(null)
  useLayoutEffect(() => {
    if (scrollRestoreRef.current !== null) {
      window.scrollTo(0, scrollRestoreRef.current)
      scrollRestoreRef.current = null
    }
  }, [filteredItems])

  const handleToggleFavorite = useCallback(
    (id, favorite) => {
      scrollRestoreRef.current = window.scrollY
      toggleFavorite(id, favorite)
    },
    [toggleFavorite]
  )

  // 2) 새로고침 후에도 스크롤 위치를 복원 (탭별로 따로 기억)
  useEffect(() => {
    const key = `naitagbox:scrollY:${activeTab}`
    const onScroll = () => {
      sessionStorage.setItem(key, String(window.scrollY))
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [activeTab])

  useEffect(() => {
    if (itemsLoading) return
    const key = `naitagbox:scrollY:${activeTab}`
    const saved = sessionStorage.getItem(key)
    if (saved) {
      requestAnimationFrame(() => window.scrollTo(0, Number(saved)))
    }
    // 로딩이 끝난 시점에 딱 한 번만 복원하면 되므로 activeTab이 바뀔 때도 다시 시도
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsLoading, activeTab])

  // ---- 선택 모드 핸들러 ----
  const toggleSelectionMode = () => {
    setSelectionMode((v) => !v)
    setSelectedIds(new Set())
  }

  const toggleSelect = useCallback((id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }, [])

  const cancelSelection = () => {
    setSelectionMode(false)
    setSelectedIds(new Set())
  }

  const handleBulkAddStyle = async (styleName) => {
    await batchAddStyle(Array.from(selectedIds), styleName)
  }
  const handleBulkSetFavorite = async (favorite) => {
    await batchSetFavorite(Array.from(selectedIds), favorite)
  }
  const handleBulkDeleteConfirmed = async () => {
    await batchDelete(Array.from(selectedIds))
    setPendingBulkDelete(false)
    cancelSelection()
  }

  // 화풍 태그 이름을 바꾸면 현재 걸려있는 필터도 새 이름으로 따라가도록,
  // 삭제하면 필터에서도 바로 제거되도록 처리
  const handleRenameStyleTag = async (tag, newName) => {
    const result = await styleTagsCtl.renameStyleTag(tag, newName)
    if (result?.success) {
      const v = newName.trim()
      setActiveStyles((prev) => prev.map((s) => (s === tag.name ? v : s)))
    }
    return result
  }

  const handleDeleteStyleTag = async (tag) => {
    await styleTagsCtl.deleteStyleTag(tag)
    setActiveStyles((prev) => prev.filter((s) => s !== tag.name))
  }

  if (authLoading) {
    return <div className="full-screen-loading">불러오는 중...</div>
  }

  if (!user) {
    return (
      <LoginScreen
        onLogin={login}
        deniedEmail={deniedEmail}
        firebaseConfigured={firebaseConfigured}
      />
    )
  }

  const CardComponent = activeTab === 'tags' ? TagCard : ComboCard
  const cardPropName = activeTab === 'tags' ? 'tag' : 'combo'
  const canSelect = activeTab === 'tags' // 요청대로 작가 태그에서만 선택/일괄 편집 지원

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="app-header-left">
          <span className="app-mark">画</span>
          <h1>작가 태그 서가</h1>
        </div>
        <div className="app-header-right">
          <span className="user-email">{user.email}</span>
          <button className="logout-btn" onClick={logout} type="button">
            로그아웃
          </button>
        </div>
      </header>

      <div className="tab-bar-wrap">
        <div className="tab-bar">
          <button
            className={`tab-btn ${activeTab === 'tags' ? 'is-active' : ''}`}
            onClick={() => switchTab('tags')}
            type="button"
          >
            작가 태그
          </button>
          <button
            className={`tab-btn ${activeTab === 'combos' ? 'is-active' : ''}`}
            onClick={() => switchTab('combos')}
            type="button"
          >
            그깍
          </button>
        </div>

        <div className="tab-bar-tools">
          <button
            type="button"
            className="btn-secondary btn-tiny"
            onClick={() => setShowStyleManager(true)}
          >
            화풍/분류 태그 관리
          </button>
          {canSelect && (
            <button
              type="button"
              className={`btn-secondary btn-tiny ${selectionMode ? 'is-active' : ''}`}
              onClick={toggleSelectionMode}
            >
              {selectionMode ? '선택 모드 끄기' : '선택'}
            </button>
          )}
        </div>
      </div>

      <FilterBar
        search={search}
        onSearchChange={setSearch}
        allStyles={allStyles}
        activeStyles={activeStyles}
        onToggleStyle={toggleStyleFilter}
        globalFilter={globalFilter}
        onGlobalFilterChange={setGlobalFilter}
        favoritesOnly={favoritesOnly}
        onToggleFavoritesOnly={() => setFavoritesOnly((v) => !v)}
        sortMode={sortMode}
        onSortModeChange={setSortMode}
      />

      {selectionMode && selectedIds.size > 0 && (
        <BulkActionBar
          count={selectedIds.size}
          allStyles={allStyles}
          onAddStyle={handleBulkAddStyle}
          onSetFavorite={handleBulkSetFavorite}
          onDelete={() => setPendingBulkDelete(true)}
          onCancel={cancelSelection}
        />
      )}

      <main className="tag-grid-wrap">
        {itemsLoading ? (
          <div className="empty-state">불러오는 중...</div>
        ) : filteredItems.length === 0 ? (
          <div className="empty-state">
            {items.length === 0
              ? activeTab === 'tags'
                ? '아직 등록된 작가 태그가 없습니다. 오른쪽 아래 + 버튼으로 추가해보세요.'
                : '아직 등록된 그깍이 없습니다. 오른쪽 아래 + 버튼으로 추가해보세요.'
              : '조건에 맞는 항목이 없습니다.'}
          </div>
        ) : isCustomOrderActive && !selectionMode ? (
          <>
            <p className="custom-order-hint">카드를 드래그해서 순서를 직접 바꿀 수 있어요.</p>
            <SortableGrid
              items={filteredItems}
              getId={(it) => it.id}
              onReorder={handleReorder}
              className="tag-grid"
              renderItem={(item) => (
                <CardComponent
                  {...{ [cardPropName]: item }}
                  globalFilter={globalFilter}
                  onToggleFavorite={handleToggleFavorite}
                  onEdit={openEdit}
                  onDelete={setPendingDelete}
                />
              )}
            />
          </>
        ) : (
          <div className="tag-grid">
            {filteredItems.map((item) => (
              <CardComponent
                key={item.id}
                {...{ [cardPropName]: item }}
                globalFilter={globalFilter}
                onToggleFavorite={handleToggleFavorite}
                onEdit={openEdit}
                onDelete={setPendingDelete}
                {...(canSelect
                  ? {
                      selectionMode,
                      selected: selectedIds.has(item.id),
                      onToggleSelect: toggleSelect,
                    }
                  : {})}
              />
            ))}
          </div>
        )}
      </main>

      {!selectionMode && (
        <button className="fab" onClick={openNew} aria-label="새 항목 추가" type="button">
          +
        </button>
      )}

      {showEditor && activeTab === 'tags' && (
        <TagEditorModal
          initial={editingItem}
          existingStyles={allStyles}
          onSave={handleSave}
          onClose={() => {
            setShowEditor(false)
            setEditingItem(null)
          }}
        />
      )}

      {showEditor && activeTab === 'combos' && (
        <ComboEditorModal
          initial={editingItem}
          existingStyles={allStyles}
          onSave={handleSave}
          onClose={() => {
            setShowEditor(false)
            setEditingItem(null)
          }}
        />
      )}

      {pendingDelete && (
        <ConfirmModal
          title="삭제할까요?"
          message={`"${displayName(pendingDelete, activeTab)}" 항목을 삭제하면 되돌릴 수 없습니다.`}
          onConfirm={handleDeleteConfirmed}
          onCancel={() => setPendingDelete(null)}
        />
      )}

      {pendingBulkDelete && (
        <ConfirmModal
          title="선택한 항목을 모두 삭제할까요?"
          message={`선택한 ${selectedIds.size}개 항목을 삭제하면 되돌릴 수 없습니다.`}
          onConfirm={handleBulkDeleteConfirmed}
          onCancel={() => setPendingBulkDelete(false)}
        />
      )}

      {showStyleManager && (
        <StyleTagManagerModal
          styleTags={styleTagsCtl.styleTags}
          onAdd={styleTagsCtl.addStyleTag}
          onRename={handleRenameStyleTag}
          onDelete={handleDeleteStyleTag}
          onClose={() => setShowStyleManager(false)}
        />
      )}
    </div>
  )
}
