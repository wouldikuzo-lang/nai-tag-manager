# 빠른 설정 체크리스트

처음 포크하신 분들이 실제로 자주 걸리는 부분들을 순서대로 정리했습니다. 자세한 설명은
[README.md](./README.md)를 참고하세요.

- [ ] Node.js 18+ 설치 확인 (`node -v`)
- [ ] (Windows) PowerShell에서 `npm`/`npx` 실행이 막히면:
      관리자 권한 PowerShell에서 `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser`
- [ ] `npm install` 실행
- [ ] Firebase 프로젝트 생성 → 웹 앱 등록 → `firebaseConfig` 값 복사
- [ ] Firebase Authentication → Google 로그인 제공자 활성화
- [ ] Firestore Database 생성
- [ ] `.env.example` → `.env` 복사 후 값 채우기 (`VITE_ALLOWED_EMAILS`는 본인 이메일로)
- [ ] `firestore.rules`의 `YOUR_EMAIL@gmail.com`을 본인 이메일로 변경
- [ ] **Firestore 규칙을 실제로 게시(Publish)했는지 확인** — 파일만 수정하고 게시를
      깜빡하면 "Missing or insufficient permissions" 에러가 계속 납니다.
      Firebase 콘솔 → Firestore Database → 규칙 탭에서 직접 붙여넣고 게시하거나,
      `firebase deploy --only firestore:rules`로 배포하세요.
- [ ] `npm run dev`로 로컬 확인
- [ ] (배포 시) `firebase deploy --only hosting` 이후, 로그인이 안 되면
      Authentication → Settings → 승인된 도메인에 배포 주소가 등록되어 있는지 확인
      (`firebase hosting:sites:create`로 커스텀 사이트 이름을 만든 경우 특히 확인 필요)
